import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const API_URL = "http://localhost/api";

// =========================================================
// SLOT CONFIGURATION
// =========================================================

const SLOT_MINUTES = 60;
const OPEN_HOUR = 6;
const CLOSE_HOUR = 22;

// Listing pagination
const ENTRIES_PER_PAGE = 25;

// PHP run_proc values
const SHIP_BOOKING_RUN_PROC = "getShipBooking";
const GET_ALL_BOOKING_RUN_PROC = "getAllBookings";

// =========================================================
// DATE HELPERS
// =========================================================

function localDateISO(date = new Date()) {
  const d = new Date(
    date.getTime() - date.getTimezoneOffset() * 60000
  );

  return d.toISOString().slice(0, 10);
}

function buildSlots(date) {
  const slots = [];

  for (
    let minutes = OPEN_HOUR * 60;
    minutes + SLOT_MINUTES <= CLOSE_HOUR * 60;
    minutes += SLOT_MINUTES
  ) {
    const hour = String(
      Math.floor(minutes / 60)
    ).padStart(2, "0");

    const minute = String(
      minutes % 60
    ).padStart(2, "0");

    const start = new Date(
      `${date}T${hour}:${minute}:00`
    );

    const end = new Date(
      start.getTime() + SLOT_MINUTES * 60000
    );

    slots.push({
      start,
      end,
      label:
        `${start.toLocaleTimeString([], {
          hour: "numeric",
          minute: "2-digit"
        })} – ${end.toLocaleTimeString([], {
          hour: "numeric",
          minute: "2-digit"
        })}`
    });
  }

  return slots;
}

function parseUtcDateTime(value) {
  if (!value) {
    return null;
  }

  let normalized = value;

  // MySQL DATETIME values are stored as UTC but do not include
  // a timezone suffix. Explicitly mark them as UTC for JavaScript.
  if (
    typeof normalized === "string" &&
    normalized.includes(" ") &&
    !normalized.includes("T")
  ) {
    normalized = normalized.replace(" ", "T") + "Z";
  }

  return new Date(normalized);
}

function overlaps(slot, booking) {
  const bookingStart = parseUtcDateTime(
    booking.start_time_utc
  );

  const bookingEnd = parseUtcDateTime(
    booking.end_time_utc
  );

  if (!bookingStart || !bookingEnd) {
    return false;
  }

  return (
    slot.start < bookingEnd &&
    slot.end > bookingStart
  );
}

// =========================================================
// MOCK DATA
// =========================================================

const mockShips = [
  {
    id: 1,
    name: "MV Atlantic Star"
  },
  {
    id: 2,
    name: "MV Gulf Trader"
  },
  {
    id: 3,
    name: "MV Southern Cross"
  }
];

const mockBookings = [
  {
    id: 1,
    ship_id: 1,
    ship_name: "MV Atlantic Star",
    pilot_name: "James Carter",
    start_time_utc:
      `${localDateISO()}T13:00:00Z`,
    end_time_utc:
      `${localDateISO()}T14:00:00Z`
  },
  {
    id: 2,
    ship_id: 1,
    ship_name: "MV Atlantic Star",
    pilot_name: "Maria Lopez",
    start_time_utc:
      `${localDateISO()}T17:00:00Z`,
    end_time_utc:
      `${localDateISO()}T19:00:00Z`
  }
];

// =========================================================
// APPLICATION
// =========================================================

export default function App() {

  // -------------------------------------------------------
  // TAB STATE
  // -------------------------------------------------------

  const [activeTab, setActiveTab] =
    useState("scheduling");

  // -------------------------------------------------------
  // DATA STATE
  // -------------------------------------------------------

  const [ships, setShips] =
    useState([]);

  const [shipId, setShipId] =
    useState("");

  const [date, setDate] =
    useState(localDateISO());

  const [pilotName, setPilotName] =
    useState("");

  const [bookings, setBookings] =
    useState([]);

  const [allBookings, setAllBookings] =
    useState([]);

  const [selectedSlot, setSelectedSlot] =
    useState(null);

  // -------------------------------------------------------
  // PAGINATION STATE
  // -------------------------------------------------------

  const [listingPage, setListingPage] =
    useState(1);

  // -------------------------------------------------------
  // UI STATE
  // -------------------------------------------------------

  const [loading, setLoading] =
    useState(true);

  const [listingLoading, setListingLoading] =
    useState(false);

  const [booking, setBooking] =
    useState(false);

  const [message, setMessage] =
    useState(null);

  const [usingMock, setUsingMock] =
    useState(false);

  // =======================================================
  // INITIAL LOAD
  // =======================================================

  useEffect(() => {
    loadShips();
  }, []);

  // =======================================================
  // LOAD SELECTED SHIP BOOKINGS
  // =======================================================

  useEffect(() => {

    if (shipId && date) {
      loadBookings(
        shipId,
        date
      );
    }

    setSelectedSlot(null);
    setMessage(null);

  }, [shipId, date]);

  // =======================================================
  // LOAD LISTING
  // =======================================================

  useEffect(() => {

    if (activeTab === "ships") {
      setListingPage(1);
      loadAllBookings();
    }

  }, [activeTab]);

  // =======================================================
  // LOAD SHIPS
  // =======================================================

  async function loadShips() {

    setLoading(true);

    try {

      const response = await fetch(
        `${API_URL}/ships.php`
      );

      if (!response.ok) {
        throw new Error(
          `HTTP error: ${response.status}`
        );
      }

      const data =
        await response.json();

      const shipData =
        Array.isArray(data)
          ? data
          : data.ships || [];

      shipData.sort(
        (a, b) =>
          (a.name || "").localeCompare(
            b.name || ""
          )
      );

      setShips(shipData);

      if (shipData.length > 0) {

		console.log(shipData);
        setShipId(
          String(shipData[0].id)
        );

      }

      setUsingMock(false);

    } catch (error) {

      console.error(
        "Unable to load ships:",
        error
      );

      const sortedMockShips =
        [...mockShips].sort(
          (a, b) =>
            a.name.localeCompare(b.name)
        );

      setShips(
        sortedMockShips
      );

      if (sortedMockShips.length > 0) {
        setShipId(
          String(
            sortedMockShips[0].id
          )
        );
      }

      setUsingMock(true);

    } finally {

      setLoading(false);

    }
  }

  // =======================================================
  // LOAD BOOKINGS FOR SHIP / DATE
  // =======================================================

  async function loadBookings(
    id,
    selectedDate
  ) {

    try {

      const response = await fetch(
        `${API_URL}/availability.php` +
        `?ship_id=${encodeURIComponent(id)}` +
        `&date=${encodeURIComponent(selectedDate)}`
      );

      if (!response.ok) {

        throw new Error(
          `HTTP error: ${response.status}`
        );

      }

      const data =
        await response.json();

      setBookings(
        data.bookings || data
      );

      setUsingMock(false);

    } catch (error) {

      console.error(
        "Unable to load availability:",
        error
      );

      setUsingMock(true);

      setBookings(
        mockBookings.filter(
          item =>
            String(item.ship_id) ===
            String(id)
        )
      );
    }
  }

  // =======================================================
  // LOAD ALL BOOKINGS
  // =======================================================

  async function loadAllBookings() {

    setListingLoading(true);

    try {

      const payload = {
        run_proc:
          GET_ALL_BOOKING_RUN_PROC
      };

      const response = await fetch(
        `${API_URL}/bookings.php`,
        {
          method: "POST",

          headers: {
            "Content-Type":
              "application/json"
          },

          body:
            JSON.stringify(payload)
        }
      );

      if (!response.ok) {

        const errorData =
          await response
            .json()
            .catch(() => ({}));

        throw new Error(
          errorData.message ||
          `HTTP error: ${response.status}`
        );
      }

      const data =
        await response.json();

      const bookingData =
        Array.isArray(data)
          ? data
          : data.bookings || [];

      setAllBookings(
        bookingData
      );

    } catch (error) {

      console.error(
        "Unable to load all bookings:",
        error
      );

      setAllBookings(
        mockBookings
      );

    } finally {

      setListingLoading(false);

    }
  }

  // =======================================================
  // SLOT CALCULATIONS
  // =======================================================

  const slots = useMemo(
    () => buildSlots(date),
    [date]
  );

  const slotRows = useMemo(
    () =>
      slots.map(slot => ({
        ...slot,

        unavailable:
          bookings.some(
            item =>
              overlaps(
                slot,
                item
              )
          )
      })),

    [slots, bookings]
  );

  // =======================================================
  // SELECTED SHIP
  // =======================================================

  const selectedShip =
    ships.find(
      ship =>
        String(ship.id) ===
        String(shipId)
    );

  // =======================================================
  // SUBMIT BOOKING
  // =======================================================

  async function submitBooking() {

    if (
      !selectedSlot ||
      !shipId ||
      !pilotName.trim()
    ) {
      return;
    }

    setBooking(true);
    setMessage(null);

    const payload = {

      ship_id:
        Number(shipId),

      pilot_name:
        pilotName.trim(),

      start_time_utc:
        selectedSlot.start.toISOString(),

      end_time_utc:
        selectedSlot.end.toISOString(),

      run_proc:
        SHIP_BOOKING_RUN_PROC
    };

    try {

      if (usingMock) {

        const demoBooking = {
          ...payload,
          id: Date.now(),
          ship_name:
            selectedShip?.name || ""
        };

        setBookings(
          previous => [
            ...previous,
            demoBooking
          ]
        );

        setAllBookings(
          previous => [
            ...previous,
            demoBooking
          ]
        );

        setMessage({
          type: "success",
          text:
            "Slot booked successfully (demo mode)."
        });

      } else {

        const response = await fetch(
          `${API_URL}/bookings.php`,
          {
            method: "POST",

            headers: {
              "Content-Type":
                "application/json"
            },

            body:
              JSON.stringify(payload)
          }
        );

        if (!response.ok) {

          const errorData =
            await response
              .json()
              .catch(() => ({}));

          throw new Error(
            errorData.message ||
            `Booking failed (${response.status})`
          );
        }

        await loadBookings(
          shipId,
          date
        );

        setMessage({
          type: "success",
          text:
            "Slot booked successfully."
        });

      }

      setSelectedSlot(null);

    } catch (error) {

      console.error(
        "Booking error:",
        error
      );

      setMessage({
        type: "error",
        text:
          error.message ||
          "Unable to create booking."
      });

      await loadBookings(
        shipId,
        date
      );

    } finally {

      setBooking(false);

    }
  }

  // =======================================================
  // FORMAT DATE
  // =======================================================

  function formatDateTime(value) {

    if (!value) {
      return "";
    }

    const parsed = parseUtcDateTime(value);

    if (
      !parsed ||
      Number.isNaN(
        parsed.getTime()
      )
    ) {
      return value;
    }

    return parsed.toLocaleString(
      [],
      {
        month: "2-digit",
        day: "2-digit",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit"
      }
    );
  }

  // =======================================================
  // MARINE SCHEDULING
  // =======================================================

  function SchedulingView() {

    return (
      <>

        <section className="controls card">

          <div className="field">

            <label htmlFor="ship">
              Ship
            </label>

            <select
              id="ship"
              value={shipId}
              disabled={loading}
              onChange={
                e =>
                  setShipId(
                    e.target.value
                  )
              }
            >

              {ships.map(
                ship => (

                  <option
                    key={ship.id}
                    value={ship.id}
                  >
                    {ship.name}
                  </option>

                )
              )}

            </select>

          </div>


          <div className="field">

            <label htmlFor="date">
              Date
            </label>

            <input
              id="date"
              type="date"
              value={date}
              min={localDateISO()}
              onChange={
                e =>
                  setDate(
                    e.target.value
                  )
              }
            />

          </div>


          <div className="field">

            <label htmlFor="pilot">
              Pilot Name
            </label>

            <input
              id="pilot"
              value={pilotName}
              placeholder="Enter pilot name"
              onChange={
                e =>
                  setPilotName(
                    e.target.value
                  )
              }
            />

          </div>

        </section>


        <section className="card schedule">

          <div className="schedule-header">

            <div>

              <h2>
                {selectedShip?.name ||
                  "Select a ship"}
              </h2>

              <p>

                {new Date(
                  `${date}T12:00:00`
                ).toLocaleDateString(
                  [],
                  {
                    weekday: "long",
                    month: "long",
                    day: "numeric",
                    year: "numeric"
                  }
                )}

              </p>

            </div>


            <div className="legend">

              <span>
                <i className="dot available" />
                Available
              </span>

              <span>
                <i className="dot unavailable" />
                Unavailable
              </span>

            </div>

          </div>


          {message && (

            <div
              className={
                `alert ${message.type}`
              }
            >
              {message.text}
            </div>

          )}


          <div className="slot-grid">

            {slotRows.map(
              slot => (

                <button
                  key={
                    slot.start.toISOString()
                  }

                  className={
                    `slot ${
                      slot.unavailable
                        ? "unavailable"
                        : ""
                    } ${
                      selectedSlot?.start.getTime() ===
                      slot.start.getTime()
                        ? "selected"
                        : ""
                    }`
                  }

                  disabled={
                    slot.unavailable
                  }

                  onClick={
                    () =>
                      setSelectedSlot(
                        slot
                      )
                  }
                >

                  <span className="slot-time">
                    {slot.label}
                  </span>

                  <span className="slot-status">

                    {slot.unavailable
                      ? "Unavailable"
                      : "Available"}

                  </span>

                </button>

              )
            )}

          </div>

        </section>


        <section className="card booking-panel">

          <div>

            <div className="eyebrow">
              BOOKING
            </div>

            <h2>

              {selectedSlot
                ? selectedSlot.label
                : "Select an available slot"}

            </h2>

            <p>

              {selectedSlot
                ? `${selectedShip?.name} on ${new Date(
                    `${date}T12:00:00`
                  ).toLocaleDateString()}`
                : "Unavailable slots cannot be selected."}

            </p>

			{!pilotName.trim() && (

			  <p className="pilot-warning">
				⚠ Pilot name is required before booking a slot.
			  </p>

			)}
          </div>


          <button
            className="primary"

            disabled={
              !selectedSlot ||
              !pilotName.trim() ||
              booking
            }

            onClick={
              submitBooking
            }
          >

            {booking
              ? "Booking..."
              : "Book Slot"}

          </button>

        </section>

      </>
    );
  }

  // =======================================================
  // MARINE SHIP LISTING
  // =======================================================

  function ShipListingView() {

    // -----------------------------------------------------
    // SORT BOOKINGS:
    // SHIP NAME A-Z, THEN DATE/TIME
    // -----------------------------------------------------

    const sortedBookings =
      [...allBookings].sort(
        (a, b) => {

          const shipCompare =
            (
              a.ship_name || ""
            ).localeCompare(
              b.ship_name || ""
            );

          if (shipCompare !== 0) {
            return shipCompare;
          }

          return (
            new Date(
              a.start_time_utc
            ) -
            new Date(
              b.start_time_utc
            )
          );
        }
      );

    // -----------------------------------------------------
    // PAGINATION
    // -----------------------------------------------------

    const totalEntries =
      sortedBookings.length;

    const totalPages =
      Math.max(
        1,
        Math.ceil(
          totalEntries /
          ENTRIES_PER_PAGE
        )
      );

    const safePage =
      Math.min(
        listingPage,
        totalPages
      );

    const startIndex =
      (safePage - 1) *
      ENTRIES_PER_PAGE;

    const endIndex =
      startIndex +
      ENTRIES_PER_PAGE;

    const pagedBookings =
      sortedBookings.slice(
        startIndex,
        endIndex
      );

    // -----------------------------------------------------
    // GROUP CURRENT PAGE BY SHIP
    // -----------------------------------------------------

    const groupedBookings =
      pagedBookings.reduce(
        (groups, item) => {

          const key =
            String(item.ship_id);

          if (!groups[key]) {

            groups[key] = {

              ship_id:
                item.ship_id,

              ship_name:
                item.ship_name ||
                "Unknown Ship",

              bookings: []
            };
          }

          groups[key].bookings.push(
            item
          );

          return groups;

        },
        {}
      );

    const shipGroups =
      Object.values(
        groupedBookings
      );

    // -----------------------------------------------------
    // CHANGE PAGE
    // -----------------------------------------------------

    function changePage(page) {

      if (
        page < 1 ||
        page > totalPages
      ) {
        return;
      }

      setListingPage(page);

      window.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }

    // -----------------------------------------------------
    // PAGE NUMBERS
    // -----------------------------------------------------

    function getPageNumbers() {

      const pages = [];

      const first =
        Math.max(
          1,
          safePage - 2
        );

      const last =
        Math.min(
          totalPages,
          safePage + 2
        );

      for (
        let page = first;
        page <= last;
        page++
      ) {
        pages.push(page);
      }

      return pages;
    }

    // -----------------------------------------------------
    // DISPLAY
    // -----------------------------------------------------

    return (

      <section className="ship-listing">

        <div className="listing-header card">

          <div>

            <div className="eyebrow">
              MARINE FLEET
            </div>

            <h2>
              Marine Ship Listing
            </h2>

            <p>
              Bookings grouped by ship
              in alphabetical order.
            </p>

          </div>


          <div className="ship-count">

            {totalEntries}{" "}

            {totalEntries === 1
              ? "Booking"
              : "Bookings"}

          </div>

        </div>


        {listingLoading ? (

          <div className="card empty-state">

            Loading marine bookings...

          </div>

        ) : totalEntries === 0 ? (

          <div className="card empty-state">

            No bookings found.

          </div>

        ) : (

          <>

            {/* ---------------------------------------------
                PAGE INFORMATION
                --------------------------------------------- */}

            <div className="listing-info">

              Showing{" "}

              <strong>
                {startIndex + 1}
              </strong>

              {" "}to{" "}

              <strong>
                {Math.min(
                  endIndex,
                  totalEntries
                )}
              </strong>

              {" "}of{" "}

              <strong>
                {totalEntries}
              </strong>

              {" "}bookings

            </div>


            {/* ---------------------------------------------
                SHIP GROUPS
                --------------------------------------------- */}

            <div className="ship-groups">

              {shipGroups.map(
                group => (

                  <section
                    key={group.ship_id}
                    className="card ship-group"
                  >

                    {/* SHIP HEADER */}

                    <div className="ship-group-header">

                      <div>


                        <h2>
                          {group.ship_name}
                        </h2>

                      </div>


                      <div className="ship-group-actions">

                        <span className="booking-count">

                          {group.bookings.length}{" "}

                          {group.bookings.length === 1
                            ? "Booking"
                            : "Bookings"}

                        </span>


                        <button
                          className="schedule-button"

                          onClick={() => {

                            setShipId(
                              String(
                                group.ship_id
                              )
                            );

                            setActiveTab(
                              "scheduling"
                            );

                          }}
                        >

                          View Schedule

                        </button>

                      </div>

                    </div>


                    {/* BOOKING TABLE */}

                    <div className="table-wrapper">

                      <table className="booking-table">

                        <thead>

                          <tr>

                            <th>
                              Booking
                            </th>

                            <th>
                              Ship
                            </th>

                            <th>
                              Pilot
                            </th>

                            <th>
                              Start
                            </th>

                            <th>
                              End
                            </th>

                          </tr>

                        </thead>


                        <tbody>

                          {group.bookings.map(
                            item => (

                              <tr
                                key={item.id}
                              >

                                <td>
                                  #{item.id}
                                </td>

                                <td>

                                  <strong>
                                    {item.ship_name}
                                  </strong>

                                </td>

                                <td>
                                  {item.pilot_name}
                                </td>

                                <td>

                                  {formatDateTime(
                                    item.start_time_utc
                                  )}

                                </td>

                                <td>

                                  {formatDateTime(
                                    item.end_time_utc
                                  )}

                                </td>

                              </tr>

                            )
                          )}

                        </tbody>

                      </table>

                    </div>

                  </section>

                )
              )}

            </div>


            {/* ---------------------------------------------
                PAGINATION
                --------------------------------------------- */}

            {totalPages > 1 && (

              <div className="pagination">

                {/* PREVIOUS */}

                <button
                  className="page-button"

                  disabled={
                    safePage === 1
                  }

                  onClick={
                    () =>
                      changePage(
                        safePage - 1
                      )
                  }
                >
                  ← Previous
                </button>


                {/* FIRST PAGE */}

                {safePage > 3 && (

                  <>
                    <button
                      className="page-button"
                      onClick={
                        () =>
                          changePage(1)
                      }
                    >
                      1
                    </button>

                    {safePage > 4 && (

                      <span className="page-dots">
                        ...
                      </span>

                    )}

                  </>

                )}


                {/* PAGE NUMBERS */}

                {getPageNumbers().map(
                  page => (

                    <button
                      key={page}

                      className={
                        page === safePage
                          ? "page-button active"
                          : "page-button"
                      }

                      onClick={
                        () =>
                          changePage(
                            page
                          )
                      }
                    >

                      {page}

                    </button>

                  )
                )}


                {/* LAST PAGE */}

                {safePage <
                  totalPages - 2 && (

                  <>

                    {safePage <
                      totalPages - 3 && (

                      <span className="page-dots">
                        ...
                      </span>

                    )}

                    <button
                      className="page-button"

                      onClick={
                        () =>
                          changePage(
                            totalPages
                          )
                      }
                    >
                      {totalPages}
                    </button>

                  </>

                )}


                {/* NEXT */}

                <button
                  className="page-button"

                  disabled={
                    safePage ===
                    totalPages
                  }

                  onClick={
                    () =>
                      changePage(
                        safePage + 1
                      )
                  }
                >
                  Next →
                </button>

              </div>

            )}

          </>

        )}

      </section>

    );
  }

  // =======================================================
  // MAIN APPLICATION
  // =======================================================

  return (

    <div className="app-shell">

      {/* HEADER */}

      <header className="topbar">

        <div>

          <div className="eyebrow">
            MARINE OPERATIONS
          </div>

          <h1>
            Marine Space Scheduling
          </h1>

          <p>
            Ship scheduling and fleet
            management.
          </p>

        </div>


        {usingMock && (

          <span className="demo-pill">
            Demo Data
          </span>

        )}

      </header>


      {/* =================================================
          TAB NAVIGATION
          ================================================= */}

      <nav className="tab-navigation">

		<button
		  className={
			activeTab === "scheduling"
			  ? "tab active"
			  : "tab"
		  }

		  onClick={() => {

			// Automatically select the first ship
			if (ships.length > 0) {
			  setShipId(
				String(ships[0].id)
			  );
			}

			setActiveTab(
			  "scheduling"
			);
		  }}
		>
		  Marine Scheduling
		</button>


        <button
          className={
            activeTab === "ships"
              ? "tab active"
              : "tab"
          }

          onClick={
            () =>
              setActiveTab(
                "ships"
              )
          }
        >

          Marine Ship Listing

        </button>

      </nav>


      {/* =================================================
          TAB CONTENT
          ================================================= */}

      <main className="content">

		{activeTab === "scheduling"
		  ? SchedulingView()
		  : ShipListingView()
		}

      </main>

    </div>
  );
}

// =========================================================
// REACT ROOT
// =========================================================

createRoot(
  document.getElementById("root")
).render(
  <App />
);