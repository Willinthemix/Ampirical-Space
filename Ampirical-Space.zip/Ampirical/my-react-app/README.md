# Ship Slot Booking React UI

React/Vite UI built directly around the supplied MySQL schema:

- `ships(id, name)`
- `bookings(id, ship_id, pilot_name, start_time_utc, end_time_utc)`

## Run

```bash
npm install
npm run dev
```

The UI initially attempts to use these API endpoints:

```text
GET  /api/ships
GET  /api/availability?ship_id=1&date=2026-09-26
POST /api/bookings
```

If the API is not available, the UI automatically uses demo data so the screen can still be previewed.

## API contract

### GET /api/ships

```json
[
  { "id": 1, "name": "MV Atlantic Star" }
]
```

### GET /api/availability

Return bookings for the selected ship/date:

```json
{
  "bookings": [
    {
      "id": 12,
      "ship_id": 1,
      "pilot_name": "James Carter",
      "start_time_utc": "2026-09-26T13:00:00Z",
      "end_time_utc": "2026-09-26T14:00:00Z"
    }
  ]
}
```

The React UI generates one-hour slots from 06:00 through 22:00 and disables a slot when:

```text
slot.start < booking.end
AND
slot.end > booking.start
```

This overlap test also handles bookings that start/end inside a generated slot.

### POST /api/bookings

Request:

```json
{
  "ship_id": 1,
  "pilot_name": "James Carter",
  "start_time_utc": "2026-09-26T15:00:00.000Z",
  "end_time_utc": "2026-09-26T16:00:00.000Z"
}
```

The backend should re-check availability inside the transaction before inserting. The UI check is for display only and is not sufficient for concurrency protection.

## Important schema note

The supplied schema does not define operating hours, slot length, holidays, or recurring schedules. Those are therefore UI configuration values in `src/main.jsx`:

```js
const SLOT_MINUTES = 60;
const OPEN_HOUR = 6;
const CLOSE_HOUR = 22;
```

For production, these should come from a scheduling/configuration table or backend API.
