<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/bootstrap.php';

try {
    $stmt = db()->query(
        'SELECT id, name
         FROM ships
         ORDER BY name ASC'
    );

    jsonResponse($stmt->fetchAll());
} catch (Throwable $e) {
    error_log($e->getMessage());
    jsonError('Unable to retrieve ships.', 500);
}
