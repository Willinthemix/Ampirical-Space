<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST, OPTIONS');
    jsonError('Only POST is supported by this endpoint.', 405);
}

$data = requestJson();

$shipId = filter_var($data['ship_id'] ?? null, FILTER_VALIDATE_INT);
$pilotName = trim((string)($data['pilot_name'] ?? ''));
$startInput = (string)($data['start_time_utc'] ?? '');
$endInput = (string)($data['end_time_utc'] ?? '');

if (!$shipId || $shipId < 1) {
    jsonError('ship_id must be a positive integer.');
}

if ($pilotName === '' || mb_strlen($pilotName) > 255) {
    jsonError('pilot_name is required and must be 255 characters or fewer.');
}

if (!validUtcDateTime($startInput) || !validUtcDateTime($endInput)) {
    jsonError('start_time_utc and end_time_utc must be ISO-8601 UTC values such as 2026-09-26T15:00:00Z.');
}

$startUtc = utcMysql($startInput);
$endUtc = utcMysql($endInput);

if ($endUtc <= $startUtc) {
    jsonError('end_time_utc must be after start_time_utc.');
}

try {
    $pdo = db();

    /*
     * MySQL/InnoDB transaction:
     * 1. Lock the ship row so concurrent bookings for the same ship
     *    serialize.
     * 2. Check interval overlap.
     * 3. Insert only when no overlap exists.
     *
     * This is important because the React availability display alone
     * cannot prevent two users from booking the same slot at once.
     */
    $pdo->beginTransaction();

    $shipStmt = $pdo->prepare(
        'SELECT id, name
         FROM ships
         WHERE id = :ship_id
         FOR UPDATE'
    );
    $shipStmt->execute(['ship_id' => $shipId]);
    $ship = $shipStmt->fetch();

    if (!$ship) {
        $pdo->rollBack();
        jsonError('Ship not found.', 404);
    }

    $overlapStmt = $pdo->prepare(
        'SELECT id, pilot_name, start_time_utc, end_time_utc
         FROM bookings
         WHERE ship_id = :ship_id
           AND start_time_utc < :new_end
           AND end_time_utc > :new_start
         LIMIT 1'
    );

    $overlapStmt->execute([
        'ship_id' => $shipId,
        'new_start' => $startUtc,
        'new_end' => $endUtc,
    ]);

    $conflict = $overlapStmt->fetch();

    if ($conflict) {
        $pdo->rollBack();

        jsonResponse([
            'error' => true,
            'message' => 'The selected slot is no longer available.',
            'code' => 'SLOT_UNAVAILABLE',
            'conflict' => $conflict,
        ], 409);
    }

    try {
        $insert = $pdo->prepare(
            'INSERT INTO bookings
                (ship_id, pilot_name, start_time_utc, end_time_utc)
             VALUES
                (:ship_id, :pilot_name, :start_time_utc, :end_time_utc)'
        );

        $insert->execute([
            'ship_id' => $shipId,
            'pilot_name' => $pilotName,
            'start_time_utc' => $startUtc,
            'end_time_utc' => $endUtc,
        ]);
    } catch (PDOException $e) {
        /*
         * The schema's uq_booking constraint protects against an
         * identical duplicate booking. Convert it into a clean 409.
         */
        if ((int)$e->errorInfo[1] === 1062) {
            $pdo->rollBack();

            jsonResponse([
                'error' => true,
                'message' => 'This booking already exists.',
                'code' => 'DUPLICATE_BOOKING',
            ], 409);
        }

        throw $e;
    }

    $bookingId = (int)$pdo->lastInsertId();
    $pdo->commit();

    jsonResponse([
        'message' => 'Booking created successfully.',
        'booking' => [
            'id' => $bookingId,
            'ship_id' => (int)$shipId,
            'ship_name' => $ship['name'],
            'pilot_name' => $pilotName,
            'start_time_utc' => $startUtc,
            'end_time_utc' => $endUtc,
        ],
    ], 201);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log($e->getMessage());
    jsonError('Unable to create booking.', 500);
}
