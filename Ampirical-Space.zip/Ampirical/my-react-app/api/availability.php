<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/bootstrap.php';

$shipId = filter_input(INPUT_GET, 'ship_id', FILTER_VALIDATE_INT);
$date = $_GET['date'] ?? '';

if (!$shipId || $shipId < 1) {
    jsonError('ship_id is required.');
}

if (!is_string($date) || !validDate($date)) {
    jsonError('date must use YYYY-MM-DD format.');
}

try {
    $pdo = db();

    $shipStmt = $pdo->prepare(
        'SELECT id, name
         FROM ships
         WHERE id = :ship_id'
    );
    $shipStmt->execute(['ship_id' => $shipId]);
    $ship = $shipStmt->fetch();

    if (!$ship) {
        jsonError('Ship not found.', 404);
    }

    // The schema stores UTC. The UI currently requests a calendar date
    // using the server/client UTC interpretation. We return all bookings
    // that overlap that UTC calendar day.
    $startUtc = $date . ' 00:00:00';
    $endUtc = (new DateTimeImmutable($startUtc, new DateTimeZone('UTC')))
        ->modify('+1 day')
        ->format('Y-m-d H:i:s');

    $stmt = $pdo->prepare(
        'SELECT
            id,
            ship_id,
            pilot_name,
            start_time_utc,
            end_time_utc
         FROM bookings
         WHERE ship_id = :ship_id
           AND start_time_utc < :day_end
           AND end_time_utc > :day_start
         ORDER BY start_time_utc ASC'
    );

    $stmt->execute([
        'ship_id' => $shipId,
        'day_start' => $startUtc,
        'day_end' => $endUtc,
    ]);

    jsonResponse([
        'ship' => $ship,
        'date' => $date,
        'timezone' => 'UTC',
        'bookings' => $stmt->fetchAll(),
    ]);
} catch (Throwable $e) {
    error_log($e->getMessage());
    jsonError('Unable to retrieve availability.', 500);
}
