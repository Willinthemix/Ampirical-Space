<?php
declare(strict_types=1);

require_once __DIR__ . '/db_config.php';


header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');



if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function jsonResponse($data, int $status = 200)
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');

    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}

function jsonError(string $message, int $status = 400, array $extra = [])
{
    jsonResponse(
        array_merge([
            'error' => true,
            'message' => $message,
        ], $extra),
        $status
    );
}


function requestJson(): array
{
    $raw = file_get_contents('php://input');

    if ($raw === false || trim($raw) === '') {
        jsonError('Request body is required.');
    }

    $data = json_decode($raw, true);

    if (!is_array($data)) {
        jsonError('Request body must be valid JSON.');
    }

    return $data;
}


function validDate(string $date): bool
{
    $d = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
    return $d !== false && $d->format('Y-m-d') === $date;
}

function validUtcDateTime(string $value): bool
{
    $d = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i:s.u\Z', $value)
       ?: DateTimeImmutable::createFromFormat('!Y-m-d\TH:i:s\Z', $value);

    return $d !== false;
}


function utcMysql(string $value): string
{
    try {

        $date = new DateTimeImmutable($value);

        $utc = new DateTimeZone('UTC');

        return $date
            ->setTimezone($utc)
            ->format('Y-m-d H:i:s');

    } catch (Throwable $e) {

        jsonError(
            'Invalid date/time: ' . $value
        );

        exit;
    }
}

