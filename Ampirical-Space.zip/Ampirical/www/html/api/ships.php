<?php

require_once "../../private/config/bootstrap.php";



$pdo = db();

// Find ships
$shipStmt = $pdo->prepare(
'SELECT *
 FROM ships'
);

$shipStmt->execute();

$ships = $shipStmt->fetchAll(PDO::FETCH_ASSOC);


    jsonResponse($ships);


