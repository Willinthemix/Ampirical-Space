<?php


require_once "../../private/config/bootstrap.php";

$shipId = filter_input(INPUT_GET, 'ship_id', FILTER_VALIDATE_INT);
$date   = $_GET['date'] ?? '';

if (!$shipId || $shipId < 1) {
    jsonError('ship_id is required.', 400);
}

if (!is_string($date) || !validDate($date)) {
    jsonError('date must use YYYY-MM-DD format.', 400);
}

try {

    $pdo = db();

    // Find ship
    $shipStmt = $pdo->prepare(
        'SELECT id, name
         FROM ships
         WHERE id = :ship_id'
    );

    $shipStmt->execute([
        'ship_id' => $shipId
    ]);

    $ship = $shipStmt->fetch();

    if (!$ship) {
        jsonError('Ship not found.', 404);
    }


    // Start of selected UTC day
    $startUtc = $date . ' 00:00:00';

    // End of selected UTC day
    $endUtc = (new DateTimeImmutable(
        $startUtc,
        new DateTimeZone('UTC')
    ))
    ->modify('+1 day')
    ->format('Y-m-d H:i:s');


    // Find bookings
    $stmt = $pdo->prepare(
        'SELECT
            id,
            ship_id,
            pilot_name,
            start_time_utc,
            end_time_utc
         FROM bookings
         WHERE ship_id = :ship_id
           AND start_time_utc < :day_end
           AND end_time_utc > :day_start
         ORDER BY start_time_utc ASC'
    );

    $stmt->execute([
        'ship_id'   => $shipId,
        'day_start' => $startUtc,
        'day_end'   => $endUtc
    ]);

    $bookings = $stmt->fetchAll();

    jsonResponse([
        'ship'     => $ship,
        'date'     => $date,
        'timezone' => 'UTC',
        'bookings' => $bookings
    ]);

} catch (Throwable $e) {

    error_log($e->getMessage());

    jsonError(
        'Unable to retrieve availability: ' . $e->getMessage(),
        500
    );
}


